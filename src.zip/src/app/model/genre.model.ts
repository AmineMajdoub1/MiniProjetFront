export class Genre {
    idJour! : number; 
    nomJour! : string;
    descJour! :string;
    prixJour!:number;

    }