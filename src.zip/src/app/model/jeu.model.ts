import { Genre } from "./genre.model";

export class Jeu {

    


    idArticle! : number;
    titreArticle! : string;
    typeArticle! : string;
    dateSortie! : Date ;
    journal! : Genre;
    }

    