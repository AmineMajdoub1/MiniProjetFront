import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.model';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  
})
export class LoginComponent implements OnInit{

  user = new User();
  err:number = 0;

  

  constructor(private authService : AuthService,
    private router: Router){}

  ngOnInit(): void {
      
  }

  onLoggedin() {
    console.log(this.user);
    let isValidUser: Boolean = this.authService.SignIn(this.user);
    if (isValidUser)
      this.router.navigate(['/articles']);
    else

    this.err = 1;
  }

}
